#ifndef WORD_H
#define WORD_H
void read_word(char *word, int len);
#endif