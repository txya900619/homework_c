#ifndef STACK_H
#define STACK_H

void push(int i);
char pop(void);
void makeempty(void);
#endif